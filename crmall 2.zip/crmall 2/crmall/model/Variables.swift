//
//  Variables.swift
//  crmall
//
//  Created by Marcio on 30/10/20.
//  Copyright © 2020 Marcio. All rights reserved.
//

import Foundation

struct Variables {

    static var originalTitle=""
    static var genresName=""
    static var overview=""
    static var posterPath=""
    static var voteAverage=""
    static var voteCount=""
    


}
